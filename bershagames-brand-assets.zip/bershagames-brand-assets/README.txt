BershaGames web marka görselleri

bershagames-symbol.webp — kurumsal sembol, açık zemin kaynaklı
bershagames-wordmark.webp — yatay BershaGames yazılı kurumsal logo
projectbersha-avatar.webp — ProjectBersha profil görseli
projectbersha-cover.webp — ProjectBersha geniş yayın kapağı

Bu görseller kullanıcı tarafından sağlanan dosyalardan WebP olarak optimize edilmiştir. Kullanım hakları ve özgünlük kullanıcı tarafından doğrulanmalıdır. Platformların resmî logoları bu pakete dahil edilmemiştir.
